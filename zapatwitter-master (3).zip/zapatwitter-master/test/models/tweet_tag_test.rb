require 'test_helper'

class TweetTagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
